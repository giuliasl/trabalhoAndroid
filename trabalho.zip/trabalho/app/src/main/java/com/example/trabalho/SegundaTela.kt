package com.example.trabalho

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class SegundaTela : AppCompatActivity() {
    private lateinit var inputCpfAtv: EditText
    private lateinit var inputPasswordAtv: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_tela)
        configureEdgeToEdge()

        inputCpfAtv = findViewById(R.id.cpf_input)
        inputPasswordAtv = findViewById(R.id.password_input)
        setupLoginButton()
    }

    private fun configureEdgeToEdge() {
        val mainView = findViewById<View>(R.id.main)
        mainView?.apply {
            ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }

    private fun setupLoginButton() {
        val loginBtn = findViewById<Button>(R.id.login_btn)
        loginBtn.setOnClickListener {
            validateCredentials()
        }
    }

    private fun validateCredentials() {
        val inputCpf = inputCpfAtv.text.toString()
        val inputPassword = inputPasswordAtv.text.toString()

        if (inputCpf == "08993356912" && inputPassword == "123456") {
            val intent = Intent(this, TerceiraTela::class.java)
            startActivity(intent)
        }
        else {
            showAlertDialog("Erro", "Os valores inseridos estão incorretos.")
        }
    }

    private fun showAlertDialog(title: String, message: String) {
        AlertDialog.Builder(this).apply {
            setTitle(title)
            setMessage(message)
            setPositiveButton("OK", null)
            create().show()
        }
    }
}





