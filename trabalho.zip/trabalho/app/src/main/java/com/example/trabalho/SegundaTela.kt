package com.example.trabalho

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class SegundaTela : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_segunda_tela)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val cpf = "08993356912"
        val pass = "123456"

        val loginBtn = findViewById<Button>(R.id.login_btn)

        loginBtn.setOnClickListener {
            val inputCpfAtv = findViewById<EditText>(R.id.cpf_input)
            val inputPasswordAtv = findViewById<EditText>(R.id.password_input)

            val inputCpf = inputCpfAtv.text.toString()
            val inputPassword = inputPasswordAtv.text.toString()

            //redirecionamento terceira tela
            if (inputCpf == cpf && inputPassword == pass) {
                val intent = Intent(this, SelectionMenu::class.java)
                startActivity(intent)

            }

            //alerta informativo
            else {
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Erro")
                builder.setMessage("Os valores inseridos estão incorretos.")
                builder.setPositiveButton("OK", null)
                val dialog = builder.create()
                dialog.show()
            }
        }
    }
}



