package com.example.trabalho;

import android.app.Activity;

public class SecondActivity extends Activity {
}
