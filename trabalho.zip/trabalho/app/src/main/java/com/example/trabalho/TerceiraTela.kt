package com.example.trabalho

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.ACTION_IMAGE_CAPTURE
import android.widget.Button

class SelectionMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terceira_tela)

        var imageUri: Uri? = null

        val button = findViewById<Button>(R.id.sel_imagem)
        val button2 = findViewById<Button>(R.id.tirar_foto)

        button.setOnClickListener{
            val intent= Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(intent, GALLERY_REQUEST_CODE)
        }

        button2.setOnClickListener{
            val intentPicture= Intent(ACTION_IMAGE_CAPTURE)
            startActivityForResult(intentPicture, CAMERA_REQUEST_CODE)
        }


    }
    companion object {
        const val GALLERY_REQUEST_CODE = 1
        const val CAMERA_REQUEST_CODE = 1
        const val SHARE_REQUEST_CODE = 2

    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      with the appropriate {@link ActivityResultContract} and handling the result in the\n      {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageURI: Uri? = data?.data
        }
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
        }

        super.onActivityResult(requestCode, resultCode, data)
    }
}