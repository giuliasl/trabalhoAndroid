package com.example.trabalho

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class TerceiraTela : AppCompatActivity() {
    private var imageUri: Uri? = null  // Variable to hold the image URI for sharing

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terceira_tela)

        val button = findViewById<Button>(R.id.sel_imagem)
        val button2 = findViewById<Button>(R.id.tirar_foto)
        val shareButton = findViewById<Button>(R.id.share_button)

        // Choose an image from the gallery
        button.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            startActivityForResult(intent, GALLERY_REQUEST_CODE)
        }

        // Capture an image using the camera
        button2.setOnClickListener {
            val intentPicture = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intentPicture, CAMERA_REQUEST_CODE)
        }

        // Share the image
        shareButton.setOnClickListener {
            imageUri?.let {
                shareImage(it)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                GALLERY_REQUEST_CODE -> {
                    imageUri = data?.data  // Get the URI of selected image
                }
                CAMERA_REQUEST_CODE -> {
                    val imageBitmap = data?.extras?.get("data") as? Bitmap
                    imageUri = data?.data  // Some devices return a Uri in the data
                    // Create a file to save the image
                    imageUri = imageBitmap?.let { bitmap ->
                        val filesDir = applicationContext.filesDir
                        val imageFile = File(filesDir, "capture.jpg")
                        val fos = FileOutputStream(imageFile)
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos)
                        fos.close()
                        FileProvider.getUriForFile(this, "${applicationContext.packageName}.provider", imageFile)
                    }
                }
            }
        }
    }

    private fun shareImage(imageUri: Uri) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, imageUri)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(Intent.createChooser(shareIntent, "Compartilhar imagem"))
    }

    companion object {
        const val GALLERY_REQUEST_CODE = 1
        const val CAMERA_REQUEST_CODE = 2
    }
}
